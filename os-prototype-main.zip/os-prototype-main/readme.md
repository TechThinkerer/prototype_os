# CPU Scheduling Simulator - OS Prototype

A comprehensive CPU scheduling simulator that implements multiple scheduling algorithms with real-time visualization through IPC (Inter-Process Communication) with a Python UI.

## 📋 Overview

This project is a backend implementation of a CPU scheduler simulator written in C, featuring multiple scheduling algorithms commonly used in operating systems. The system simulates process scheduling, tracks performance metrics, and communicates with a Python-based UI through Unix domain sockets.

## ✨ Features

### Implemented Scheduling Algorithms
1. **FCFS (First-Come, First-Served)** - Non-preemptive scheduling based on arrival time
2. **SJF (Shortest Job First)** - Non-preemptive scheduling based on burst time
3. **SRTN (Shortest Remaining Time Next)** - Preemptive version of SJF


### Key Features
- **Process State Management**: Tracks process states (READY, RUNNING, WAITING, TERMINATED)
- **Performance Metrics**: Calculates turnaround time, waiting time, and completion time
- **Thread-Safe Operations**: Uses pthread mutex for concurrent data access
- **Real-Time IPC**: Sends scheduling updates to UI via Unix domain sockets
- **Configurable Parameters**: Supports custom quantum values and process counts
- **MLFQ Aging Mechanism**: Prevents starvation in multi-level queues

## 🏗️ Architecture

### Core Components

#### 1. **scheduler.h** - Header File
Defines the core data structures:
- `Process` (PCB - Process Control Block)
- `SystemState` (Global system state)
- `ProcessState` enum (Process states)
- `MLFQData` (MLFQ-specific data)

#### 2. **main.c** - Entry Point
- Parses command-line arguments
- Initializes the system
- Manages IPC connection
- Inputs process data
- Runs scheduler
- Reports final metrics

#### 3. **process.c** - Process Management
- `init_system()`: Initializes system state and mutex
- `add_process()`: Creates and adds new processes with thread-safe access

#### 4. **algorithms.c** - Scheduling Logic
- `select_process()`: Implements all scheduling algorithms
- `run_scheduler()`: Main simulation loop
- Handles preemption and context switching

#### 5. **ipc.c** - Inter-Process Communication
- `connect_to_ui()`: Establishes Unix socket connection
- `send_update_to_ui()`: Sends JSON-formatted state updates
- `close_ipc()`: Cleans up socket resources

## 🚀 Getting Started

### Prerequisites
- GCC compiler
- pthread library
- Make utility
- Unix/Linux environment

### Building the Project

```bash
# Build the scheduler
make

# Clean build artifacts
make clean
```

The compiled binary will be located at `bin/scheduler`.

### Running the Simulator

```bash
./bin/scheduler <Algorithm> <Quantum> <Process_Count>
```

**Parameters:**
- `<Algorithm>`: One of: FCFS, SJF, SRTN, Priority, RR, MLFQ
- `<Quantum>`: Time quantum for RR and MLFQ (use 0 for non-preemptive algorithms)
- `<Process_Count>`: Number of processes to simulate

**Example:**
```bash
./bin/scheduler RR 2 5
```

### Input Format

After launching, the program expects process data via stdin:
```
PID Arrival_Time Burst_Time Priority
```

**Example Input:**
```
1 0 5 1
2 1 3 2
3 2 8 3
4 3 6 1
5 4 4 2
```

## 📊 Output

The simulator provides:
1. **Real-time updates** via IPC to connected UI
2. **Final metrics** including:
   - Per-process turnaround time
   - Per-process waiting time
   - Average turnaround time
   - Average waiting time

**Sample Output:**
```
--- Final Metrics ---
PID     Turnaround      Waiting
1       5               0
2       7               4
3       18              10
4       17              11
5       15              11
--------------------------------------------
Average Turnaround Time: 12.40
Average Waiting Time: 7.20
```

## 🔧 Configuration

### MLFQ Queue Configuration
The MLFQ algorithm uses three priority queues with different time quantums:
- **Queue 0 (High Priority)**: Quantum = 2
- **Queue 1 (Medium Priority)**: Quantum = 4
- **Queue 2 (Low Priority)**: Quantum = 8

### Maximum Processes
Default: `MAX_PROCESSES = 100` (defined in `scheduler.h`)

### IPC Socket Path
Default: `/tmp/scheduler_socket` (defined in `ipc.c`)

## 🧵 Concurrency

The system uses pthread mutex locks to ensure thread-safe operations when:
- Adding new processes to the system
- Accessing shared system state
- Modifying process control blocks

## 📡 IPC Protocol

The backend sends JSON-formatted updates to the UI:

```json
{
  "time": 5,
  "processes": [
    {
      "pid": 1,
      "state": 3,
      "remaining": 0,
      "ct": 5,
      "tat": 5,
      "wt": 0,
      "queue": -1
    }
  ]
}
```

**Fields:**
- `time`: Current simulation time
- `state`: 0=READY, 1=RUNNING, 2=WAITING, 3=TERMINATED
- `remaining`: Remaining burst time
- `ct`: Completion time
- `tat`: Turnaround time
- `wt`: Waiting time
- `queue`: MLFQ queue level (-1 if not using MLFQ)

## 🛠️ Development

### Project Structure
```
os_prototype/
├── Makefile              # Build configuration
├── readme.md             # This file
├── src/
│   └── backend/
│       ├── main.c        # Entry point
│       ├── scheduler.h   # Header definitions
│       ├── process.c     # Process management
│       ├── algorithms.c  # Scheduling algorithms
│       └── ipc.c         # Inter-process communication
├── bin/                  # Compiled binaries (generated)
└── obj/                  # Object files (generated)
```

### Compilation Flags
- `-Wall`: Enable all warnings
- `-Wextra`: Enable extra warnings
- `-pthread`: Enable POSIX threading support
- `-g`: Include debugging information

## 📚 Algorithm Details

### FCFS (First-Come, First-Served)
- Non-preemptive
- Processes executed in arrival order
- Simple but can cause convoy effect

### SJF (Shortest Job First)
- Non-preemptive
- Selects process with shortest burst time
- Optimal for minimizing average waiting time

### SRTN (Shortest Remaining Time Next)
- Preemptive version of SJF
- Can preempt currently running process
- Optimal for preemptive scheduling

### Priority Scheduling
- Non-preemptive
- Lower priority number = higher priority
- Risk of starvation for low-priority processes

### Round Robin (RR)
- Preemptive time-slicing
- Each process gets equal CPU time quantum
- Fair but context switching overhead

### MLFQ (Multi-Level Feedback Queue)
- Three-level priority queue system
- Processes demoted on quantum exhaustion
- Aging mechanism prevents starvation
- Balances responsiveness and throughput

## 🤝 Contributing

To extend this project:
1. Add new algorithms in `algorithms.c`
2. Update `select_process()` function
3. Modify PCB structure if needed
4. Update IPC protocol for new metrics

## 📄 License

This project is an educational OS prototype for learning CPU scheduling concepts.

## 👤 Author

Abdul Wasay

## 🙏 Acknowledgments

Built as part of an Operating Systems course project to demonstrate understanding of:
- CPU scheduling algorithms
- Process management
- Inter-process communication
- Concurrent programming with threads
